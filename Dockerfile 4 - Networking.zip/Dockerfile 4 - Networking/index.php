<?php
for ($i; $i < 10; $i++){
     echo "Item number ".$i." \r\n";
	 echo "<br>";
}
?>